<?php
// 检查系统是否已安装（使用绝对路径检查）
$basePath = dirname(__DIR__);
if (!file_exists($basePath . '/config/database.php') || !file_exists($basePath . '/includes/init.php')) {
    // 系统未安装，重定向到安装向导
    header('Location: ../install/');
    exit();
}

session_start();

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// 包含初始化文件
require_once '../includes/init.php';

// 获取用户信息
try {
    $stmt = $pdo->prepare("SELECT username, email, points FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if ($user) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['points'] = $user['points'];
    } else {
        // 用户不存在，退出登录
        session_destroy();
        header('Location: login.php');
        exit();
    }
    
    // 获取用户加密文件数量
    $stmt = $pdo->prepare("SELECT COUNT(*) as encrypted_count FROM encrypt_tasks WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $encrypted_count = $stmt->fetch()['encrypted_count'];
    
    // 获取用户已使用的积分（加密）
    $stmt = $pdo->prepare("SELECT COUNT(*) as encrypt_count FROM encrypt_tasks WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $encrypt_count = $stmt->fetch()['encrypt_count'];
    
    $points_per_encrypt = (int)get_system_config('points_per_encrypt', 10);
    $points_used_for_encryption = $encrypt_count * $points_per_encrypt;
    
    // 获取用户已使用的积分（解密）
    $stmt = $pdo->prepare("SELECT COUNT(*) as decrypt_count FROM decrypt_tasks WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $decrypt_count = $stmt->fetch()['decrypt_count'];
    
    $points_per_decrypt = (int)get_system_config('points_per_decrypt', 5);
    $points_used_for_decryption = $decrypt_count * $points_per_decrypt;
    
    // 总共使用的积分
    $total_points_used = $points_used_for_encryption + $points_used_for_decryption;
} catch (Exception $e) {
    $error = '获取用户信息时出错: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户中心 - PHP加密解密系统</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>用户中心</h2>
            <ul>
                <li><a href="dashboard.php" class="active">仪表板</a></li>
                <li><a href="encrypt.php">代码加密</a></li>
                <li><a href="decrypt.php">代码解密</a></li>
                <li><a href="points.php">积分充值</a></li>
                <li><a href="profile.php">个人资料</a></li>
                <li><a href="logout.php">退出登录</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="header">
                <h1>用户仪表板</h1>
                <div>欢迎，<?php echo htmlspecialchars($_SESSION['username']); ?> | <a href="logout.php">退出</a></div>
            </div>
            
            <div class="stats-container">
                <div class="stats">
                    <div class="stat-card">
                        <h3>已加密文件</h3>
                        <div class="number"><?php echo $encrypted_count ?? 0; ?></div>
                    </div>
                    
                    <div class="stat-card">
                        <h3>已用积分</h3>
                        <div class="number"><?php echo $total_points_used ?? 0; ?></div>
                    </div>
                    
                    <div class="stat-card">
                        <h3>剩余积分</h3>
                        <div class="number"><?php echo $_SESSION['points'] ?? 0; ?></div>
                    </div>
                </div>
            </div>
            
            <div class="content">
                <h2>用户信息</h2>
                <p>用户名: <?php echo htmlspecialchars($user['username'] ?? ''); ?></p>
                <p>邮箱: <?php echo htmlspecialchars($user['email'] ?? ''); ?></p>
                <p>积分余额: <span class="number"><?php echo $_SESSION['points'] ?? 0; ?></span> 分</p>
            </div>
            
            <div class="actions">
                <div class="action-card">
                    <h3>代码加密</h3>
                    <p>使用多种算法加密您的PHP代码</p>
                    <a href="encrypt.php" class="btn">开始加密</a>
                </div>
                
                <div class="action-card">
                    <h3>代码解密</h3>
                    <p>解密已加密的PHP代码文件</p>
                    <a href="decrypt.php" class="btn">开始解密</a>
                </div>
                
                <div class="action-card">
                    <h3>积分充值</h3>
                    <p>使用卡密充值积分</p>
                    <a href="points.php" class="btn btn-success">充值积分</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>