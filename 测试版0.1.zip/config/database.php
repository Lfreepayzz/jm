<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'encryption_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// 系统配置
define('UPLOAD_MAX_SIZE', 2097152); // 2MB
define('SITE_NAME', 'PHP加密解密系统');
?>